import json
import sqlite3
import pytest
from sentinelforge.core import load_events, detect, redact, connect, save, approve, advise

def test_rules():
    events = [{'host':'pc1','user':'a','source_ip':'10.0.0.2','event_id':'4625','message':'failed login'} for _ in range(5)]
    events += [{'host':'pc1','user':'a','source_ip':'','event_id':'1102','message':'audit log was cleared'}]
    rules = {x['rule'] for x in detect(events)}
    assert rules == {'REPEATED_LOGON_FAILURES', 'AUDIT_LOG_CLEARED'}

def test_load_and_limit(tmp_path):
    p = tmp_path / 'events.jsonl'
    p.write_text(json.dumps({'event_id': 4720, 'message': 'created'}) + '\n', encoding='utf8')
    assert load_events(p)[0]['event_id'] == '4720'
    p.write_text('not-json\n', encoding='utf8')
    with pytest.raises(json.JSONDecodeError):
        load_events(p)

def test_memory(tmp_path):
    db = connect(tmp_path / 'db.sqlite')
    i = save(db, 'test', [], [], 'none')
    approve(db, i, 'review account', 'analyst', 'manual')
    assert db.execute('SELECT COUNT(*) FROM approvals').fetchone()[0] == 1
    db.close()

def test_redaction():
    assert 'abc123' not in redact('token=abc123')

def test_endpoint_guard():
    with pytest.raises(ValueError):
        advise([], [], endpoint='http://example.com/api/chat')
