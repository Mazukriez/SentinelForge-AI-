# SentinelForge AI

Local-first defensive cybersecurity investigation agent. **MVP / not production-certified.**

## Windows PowerShell quickstart

Install Python 3.11+ from https://www.python.org/downloads/windows/ and Ollama from https://ollama.com/download/windows. Open a new PowerShell terminal:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[test]"
ollama pull llama3.2
ollama list
python -m sentinelforge scan samples/security-events.jsonl
python -m sentinelforge history
python -m sentinelforge show 1
python -m pytest -q
```

If script activation is blocked, use `.\.venv\Scripts\python.exe` in place of `python` without activating the environment. Ollama must be running locally; on Windows it usually runs after launching the app. For an offline rule-only scan:

```powershell
python -m sentinelforge scan samples/security-events.jsonl --no-llm
```

Approval is an audit record, **not** permission to execute any command:

```powershell
python -m sentinelforge approve 1 --action "Review suspicious account" --approver "SOC-analyst" --note "Ticket reviewed"
```

## Input format

JSONL: one JSON object per line, fields `timestamp`, `host`, `user`, `event_id`, `source_ip`, `message`. Only synthetic sample logs are included. 2 MB / 10,000-event hard limits. Use only authorized, sanitized logs.

## Architecture

`JSONL -> validation -> deterministic detection -> local Ollama advisory triage -> SQLite investigation history -> manual review/approval`

The agent does **not** run shell commands, scan networks, modify systems, isolate hosts, or push changes. It does not ingest raw Windows Event Log (`.evtx`) files; export and normalize to JSONL first.

## Caveats

- The 5-failure rule is a batch count by host/user/IP, **not** a time-window brute-force detector. Findings are leads, not confirmed incidents.
- Logs can contain prompt injection, PII, and secrets. Regex redaction is incomplete. Ollama receives up to 25 sanitized event summaries; findings can still contain source metadata. Never feed highly sensitive production logs without a data-classification review.
- SQLite history stores findings and analysis, not full raw events. SQLite is not encrypted by default and the audit trail is not tamper-evident.
- Local-only API URL guard does not guarantee a sandbox or prevent other host processes from accessing Ollama. Keep it bound to loopback and restrict host access.
- No endpoint execution, SIEM connector, scheduling, multi-user authentication, RBAC, retention policy, backup, or dashboard is implemented in this MVP.

## Roadmap

1. Event schemas, timestamp normalization, deduplication, sliding-window correlation, unit/integration tests.
2. SIEM adapters with read-only credentials and scoped permissions; ingestion queue, checkpoints, retries.
3. Local dashboard with authentication, RBAC, encryption-at-rest, retention and tamper-evident logs.
4. Tool gateway with allowlisted read-only operations, explicit approvals and a separately isolated action executor.
5. ATT&CK mapping, evidence provenance, benchmark datasets, red-team prompt-injection testing and model evaluations.

See `docs/SECURITY.md` for threat model and deployment checklist.
