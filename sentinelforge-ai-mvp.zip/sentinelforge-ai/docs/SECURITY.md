# Security model and deployment checklist

## Trust boundaries

1. JSONL events are untrusted data, including any embedded instructions.
2. Local Ollama output is advisory untrusted text, never executable instructions.
3. SQLite is local persistent memory, not an immutable security ledger.
4. `approve` writes a review record only. There is no actuator or remediation execution path.

## Controls present in MVP

- Only `.jsonl` input, 2 MB file cap and 10,000-event cap.
- Fixed event fields and truncated field lengths.
- Deterministic detection separate from LLM.
- Loopback-only Ollama endpoint; HTTP request timeout.
- Parameterized SQL queries and foreign keys.
- No shell, remote scan, external URLs, or execution tool.
- Explicit failure handling if Ollama is unavailable.

## Before production

- Add strong local auth and RBAC; protect the database with encryption and restrictive filesystem ACLs.
- Implement comprehensive secret and PII filtering; isolate sensitive data from prompts.
- Validate event timestamps and schema, deduplicate, normalize identities and enrich via trusted feeds.
- Add SIEM read-only service principals, rate limits, telemetry and health checks.
- Add durable queue, backpressure, retries, incident lifecycle, approvals and immutable external audit logs.
- Add unit, integration, adversarial, performance and detection-quality evaluations.
- Introduce any remediation executor only in a separate privilege domain with per-action authorization, rollback, dry-run and dual approval for high-impact actions.
- Keep Ollama loopback-only, patch dependencies, pin versions, review model licenses and avoid exposing the API to the LAN.
