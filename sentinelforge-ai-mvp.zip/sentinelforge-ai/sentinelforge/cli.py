import argparse
import json
from .core import load_events, detect, advise, connect, save, approve


def main():
    parser = argparse.ArgumentParser(description='SentinelForge local defensive SOC agent')
    parser.add_argument('--db', default='data/sentinelforge.db')
    sub = parser.add_subparsers(dest='command', required=True)
    scan = sub.add_parser('scan', help='Analyze a JSONL log file')
    scan.add_argument('file')
    scan.add_argument('--model', default='llama3.2')
    scan.add_argument('--no-llm', action='store_true')
    sub.add_parser('history', help='Show prior investigations')
    review = sub.add_parser('show', help='Show an investigation')
    review.add_argument('id', type=int)
    approval = sub.add_parser('approve', help='Record approval ONLY; never executes action')
    approval.add_argument('id', type=int)
    approval.add_argument('--action', required=True)
    approval.add_argument('--approver', required=True)
    approval.add_argument('--note', default='')
    args = parser.parse_args()
    db = connect(args.db)
    if args.command == 'scan':
        events = load_events(args.file)
        findings = detect(events)
        if args.no_llm:
            analysis = 'LLM disabled. Deterministic findings only.'
        else:
            try:
                analysis = advise(events, findings, model=args.model)
            except Exception as exc:
                analysis = f'LLM unavailable ({type(exc).__name__}); findings remain available.'
        record_id = save(db, args.file, events, findings, analysis)
        print(json.dumps({'investigation_id': record_id, 'event_count': len(events), 'findings': findings, 'analysis': analysis}, indent=2))
    elif args.command == 'history':
        for row in db.execute('SELECT id,created_at,source,event_count FROM investigations ORDER BY id DESC LIMIT 30'):
            print(*row, sep=' | ')
    elif args.command == 'show':
        row = db.execute('SELECT id,created_at,source,event_count,findings_json,analysis FROM investigations WHERE id=?', (args.id,)).fetchone()
        if row is None:
            parser.error('Investigation not found')
        print(json.dumps(dict(zip(('id','created_at','source','event_count','findings','analysis'), (row[0],row[1],row[2],row[3],json.loads(row[4]),row[5]))), indent=2))
    elif args.command == 'approve':
        try:
            approve(db, args.id, args.action, args.approver, args.note)
        except Exception as exc:
            parser.error(str(exc))
        print('Approval recorded. NO action was executed.')
    db.close()

if __name__ == '__main__':
    main()
